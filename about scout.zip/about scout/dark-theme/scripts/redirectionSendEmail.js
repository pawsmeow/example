function send()
{
    window.location.href = "sendEmail.html"
}